public class Humano {
    private String name;
    private int idade;
    private float altura;

    //métodos que retornam e permitem alteração das propriedades da classe Humano
    //get retorna valores e set permite alterações ou adição de valores
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    

}


